const rows = 20;
const cols = 10;
const fallSpeed = [1000, 800, 600, 500, 300, 200];
const lineGoal = [5, 10, 15, 20, 25, 30];
const startButton = document.getElementById("start_button");
const stopButton = document.getElementById("stop_button");
const restartButton = document.getElementById("restart_button");
const title = document.querySelector("h1");
const scoreText = document.getElementById("score");
const totalScoreText = document.getElementById("total_score");
const lineText = document.getElementById("line");
const playField = document.getElementById("playfield");
const nextPieceBox = document.getElementById("next_piece");
const levelText = document.getElementById("level");
const levelInput = document.querySelectorAll('input[name="level"]');
const board = Array.from({length: rows}, () => Array(cols).fill(0));

let pieceRow = 0;
let pieceCol = 0;
let gameOver = false;
let gameTime = null;
let score = 0;
let totalScore = 0;
let totalLine = 0;
let garbageLine = 5;
let pieceCount = 0;
let rotationLock = false;
let currentPiece = null;
let nextPiece = null;

function getSelectLevel() {
    return Number(document.querySelector('input[name="level"]:checked').value);
}

let level = getSelectLevel();

const shapeI = [
    [1, 1, 1, 1]
];
const shapeO = [
    [1, 1],
    [1, 1]
];
const shapeT = [
    [0, 1, 0],
    [1, 1, 1]
];
const shapeS = [
    [0, 1, 1],
    [1, 1, 0]
];
const shapeZ = [
    [1, 1, 0],
    [0, 1, 1]
];
const shapeJ = [
    [1, 0, 0],
    [1, 1, 1]
];
const shapeL = [
    [0, 0, 1],
    [1, 1, 1]
];
const shapeIUpper = [
    [1, 1, 1],
    [0, 1, 0],
    [0, 1, 0],
    [1, 1, 1]
];
const shapeU = [
    [1, 0, 1],
    [1, 1, 1]
];
const shapeBomb = [
    [0, 1, 1, 0],
    [1, 1, 1, 1],
    [0, 1, 1, 0],
    [0, 1, 1, 0]
];

const basicPiece = [
    {name: "I", shape: shapeI},
    {name: "O", shape: shapeO},
    {name: "T", shape: shapeT},
    {name: "S", shape: shapeS},
    {name: "Z", shape: shapeZ},
    {name: "J", shape: shapeJ},
    {name: "L", shape: shapeL}
];
const level2Piece = [
    {name: "I", shape: shapeI},
    {name: "O", shape: shapeO},
    {name: "T", shape: shapeT},
    {name: "S", shape: shapeS},
    {name: "Z", shape: shapeZ},
    {name: "J", shape: shapeJ},
    {name: "L", shape: shapeL},
    {name: "I2", shape: shapeIUpper},
    {name: "U", shape: shapeU}
];
const level5Piece = [
    ...basicPiece,
    {name: "Bomb", shape: shapeBomb}
];

// lay khoi ngau nhien de tha xuong
function getRandomPiece() {
    let pieceList = basicPiece;
    if (level === 2) {
        pieceList = level2Piece;
    } else if (level === 5) {
        pieceList = level5Piece;
    }
    const randomIndex = Math.floor(Math.random() * pieceList.length);
    const piece = pieceList[randomIndex];
    const shapeCopy = [];
    for (let row = 0; row < piece.shape.length; row++) {
        shapeCopy.push(piece.shape[row].slice());
    }
    return {
        name: piece.name,
        shape: shapeCopy
    };
}

// ve luoi
function drawGrid() {
    for (let row = 0; row < rows; row++) {
        for (let col = 0; col < cols; col++) {
            const cell = document.createElement("div");
            cell.id = `cell-${row}-${col}`;
            cell.classList.add("cell");
            playField.appendChild(cell);
        }
    }
}

// dat 6 vat can ngau nhien vao 5 duoi day khi bat dau lv6
function addObstacle() {
    let obstacleCount = 0;
    while (obstacleCount < 6) {
        let row = Math.floor(Math.random() * 5) + 14;
        let col = Math.floor(Math.random() * cols);
        if (board[row][col] === 0) {
            board[row][col] = "obstacle";
            obstacleCount++;
        }
    }
}

// xoa vat can
function clearObstacle() {
    for (let row = 0; row < rows; row++) {
        for (let col = 0; col < cols; col++) {
            if (board[row][col] === "obstacle") board[row][col] = 0;
        }
    }
}

// ve cac khoi khi da roi xuong cham day va khong nhuc nhich
function drawSaveBlock() {
    for (let row = 0; row < rows; row++) {
        for (let col = 0; col < cols; col++) {
            if (board[row][col] !== 0) {
                const cell = document.getElementById(`cell-${row}-${col}`);
                cell.classList.add(board[row][col]);
            }
        }
    }
}

// ve lai man game voi cac o
function drawBackground() {
    for (let row = 0; row < rows; row++) {
        for (let col = 0; col < cols; col++) {
            const cell = document.getElementById(`cell-${row}-${col}`);
            cell.className = "cell";
        }
    }
    drawSaveBlock();
    if (!gameOver && currentPiece !== null) {
        for (let row = 0; row < currentPiece.shape.length; row++) {
            for (let col = 0; col < currentPiece.shape[row].length; col++) {
                if (currentPiece.shape[row][col] === 1) {
                    const screenRow = pieceRow + row;
                    const screenCol = pieceCol + col;
                    const cell = document.getElementById(`cell-${screenRow}-${screenCol}`);
                    if (cell) cell.classList.add(currentPiece.name);
                }
            }
        }
    }
}

// ve khoi tiep theo cho Ui khoi tiep theo
function drawNextPiece() {
    nextPieceBox.innerHTML = "";
    const pieceWidth = nextPiece.shape[0].length;
    let columnStyle = "";
    for (let i = 0; i < pieceWidth; i++) {
        columnStyle += "24px ";
    }
    nextPieceBox.style.display = "grid";
    nextPieceBox.style.gridTemplateColumns = columnStyle;
    nextPieceBox.style.gap = "2px";
    for (let row = 0; row < nextPiece.shape.length; row++) {
        for (let col = 0; col < nextPiece.shape[row].length; col++) {
            const cell = document.createElement("div");
            cell.classList.add("cell");
            if (nextPiece.shape[row][col] === 1) {
                cell.classList.add(nextPiece.name);
            } else {
                cell.classList.add("empty");
            }
            nextPieceBox.appendChild(cell);
        }
    }
}

// kiem tra va cham voi khoi khac ,voi tuong va voi day
function haveBlock(rowCheck, colCheck) {
    for (let row = 0; row < currentPiece.shape.length; row++) {
        for (let col = 0; col < currentPiece.shape[row].length; col++) {
            if (currentPiece.shape[row][col] === 1) {
                const rowLine = rowCheck + row;
                const colLine = colCheck + col;
                if (colLine < 0 || colLine >= cols || rowLine >= rows) return true;
                if (rowLine >= 0 && board[rowLine][colLine] !== 0) return true;
            }
        }
    }
    return false;
}

// luu khoi hien tai vao board khi da cham day hoac cham khoi khac
function saveBlock() {
    for (let row = 0; row < currentPiece.shape.length; row++) {
        for (let col = 0; col < currentPiece.shape[row].length; col++) {
            if (currentPiece.shape[row][col] === 1) {
                const rowLine = pieceRow + row;
                const colLine = pieceCol + col;
                if (rowLine >= 0) board[rowLine][colLine] = currentPiece.name;
            }
        }
    }
}

// xoa hang khi duoc lap day
function clearLine() {
    let lineCount = 0;
    for (let row = rows - 1; row >= 0; row--) {
        let isFull = true;
        let hasObstacle = false;
        for (let col = 0; col < cols; col++) {
            if (board[row][col] === 0) isFull = false;
            if (board[row][col] === "obstacle") hasObstacle = true;
        }
        if (isFull && !hasObstacle) {
            board.splice(row, 1);
            board.unshift(Array(cols).fill(0));
            lineCount++;
            row++;
        }
    }
    return lineCount;
}

// them 1 hang rac (co 2 lo ngau nhien) o day
function addGarbageRow() {
    for (let col = 0; col < cols; col++) {
        if (board[0][col] !== 0) {
            gameOver = true;
            pauseGame();
            title.textContent = "Game Over";
            return;
        }
    }
    const garbageRow = Array(cols).fill("garbage");
    const hole1 = Math.floor(Math.random() * cols);
    let hole2 = Math.floor(Math.random() * cols);
    while (hole2 === hole1) {
        hole2 = Math.floor(Math.random() * cols);
    }
    garbageRow[hole1] = 0;
    garbageRow[hole2] = 0;
    board.shift();
    board.push(garbageRow);
}

// cap nhat diem sau moi lan xoa hang
function updateScore(lineCount) {
    const point = [0, 100, 300, 500, 700];
    let gainPoint = point[lineCount] || 0;
    score += gainPoint;
    totalScore += gainPoint;
    totalLine += lineCount;
    scoreText.textContent = score;
    totalScoreText.textContent = totalScore;
    lineText.textContent = totalLine;
}

// dat khoi hien tai len dau man hinh, sinh khoi ke tiep
function spawnPiece(piece) {
    currentPiece = piece;
    nextPiece = getRandomPiece();
    pieceRow = 0;
    pieceCol = Math.floor((cols - currentPiece.shape[0].length) / 2);
    pieceCount++;
    rotationLock = level === 4 && pieceCount % 5 === 0;
    if (rotationLock) {
        title.textContent = "Khối này không thể xoay";
    } else {
        title.textContent = "Welcome to Tetris";
    }
    drawNextPiece();
}

// khoa lv khi dang choi
function setLevelLock(lock) {
    levelInput.forEach(input => {
        input.disabled = lock;
    });
}

// chon lv khi khong dang choi
function selectLevel(newLevel) {
    clearObstacle();
    level = Number(newLevel);
    score = 0;
    scoreText.textContent = score;
    totalScoreText.textContent = totalScore;
    levelText.textContent = level;
    pieceCount = 0;
    garbageLine = totalLine + 5;
    rotationLock = false;
    if (level === 6) addObstacle();
    spawnPiece(getRandomPiece());
    drawBackground();
}

// co che no bomb 4x4 cua lv5 tinh tu than bomb tro xuong
function explodeBomb() {
    for (let row = pieceRow + 2; row < pieceRow + 6; row++) {
        for (let col = pieceCol; col < pieceCol + 4; col++) {
            if (row >= 0 && row < rows && col >= 0 && col < cols) {
                if (board[row][col] !== 0) {
                    board[row][col] = 0;
                    score += 10;
                    totalScore += 10;
                }
            }
        }
    }
    scoreText.textContent = score;
    totalScoreText.textContent = totalScore;
}

// cho qua lv moi khi dat du kpi
function passLevel() {
    pauseGame();
    if (level === 6) {
        gameOver = true;
        title.textContent = "Bạn đã phá đảo! Tổng điểm: " + totalScore;
        drawBackground();
        return;
    }
    levelInput[level].checked = true;
    selectLevel(level + 1);
    title.textContent = "Lên Lv" + level + "!";
    gameTime = setInterval(moveDown, fallSpeed[level - 1]);
}

// cho khoi roi xuong , neu cham thi xu ly su kien
function moveDown() {
    if (!haveBlock(pieceRow + 1, pieceCol)) {
        pieceRow++;
    } else {
        if (currentPiece.name === "Bomb" && level === 5) {
            explodeBomb();
        } else {
            saveBlock();
            const lineCount = clearLine();
            updateScore(lineCount);
            if (level === 3 && totalLine >= garbageLine) {
                addGarbageRow();
                garbageLine += 5;
                if (gameOver) {
                    drawBackground();
                    return;
                }
            }
            if (totalLine >= lineGoal[level - 1]) {
                passLevel();
                return;
            }
        }
        spawnPiece(nextPiece);
        if (haveBlock(pieceRow, pieceCol)) {
            gameOver = true;
            pauseGame();
            title.textContent = "Game Over";
        }
    }
    drawBackground();
}

// nut bat dau
function startGame() {
    if (gameTime !== null || gameOver) return;
    setLevelLock(true);
    gameTime = setInterval(moveDown, fallSpeed[level - 1]);
}

// nut tam dung
function pauseGame() {
    clearInterval(gameTime);
    gameTime = null;
}

//nut choi lai, chi reset diem cua lv
function restartGame() {
    pauseGame();
    for (let row = 0; row < rows; row++) {
        board[row].fill(0);
    }
    gameOver = false;
    score = 0;
    totalLine = 0;
    scoreText.textContent = score;
    totalScoreText.textContent = totalScore;
    lineText.textContent = totalLine;
    title.textContent = "Welcome to Tetris";
    setLevelLock(false);
    selectLevel(getSelectLevel());
}

// di chuyen khoi qua lai
function movePiece(direction) {
    if (!haveBlock(pieceRow, pieceCol + direction)) {
        pieceCol += direction;
        drawBackground();
    }
}

// xoay khoi 90 do theo chieu kim dong ho
function rotatePiece() {
    if (rotationLock) return;
    const oldShape = currentPiece.shape;
    const oldHeight = oldShape.length;
    const oldWidth = oldShape[0].length;
    const newShape = [];
    for (let i = 0; i < oldWidth; i++) {
        newShape.push(Array(oldHeight).fill(0));
    }
    for (let row = 0; row < oldHeight; row++) {
        for (let col = 0; col < oldWidth; col++) {
            newShape[col][oldHeight - 1 - row] = oldShape[row][col];
        }
    }
    currentPiece.shape = newShape;
    if (haveBlock(pieceRow, pieceCol)) currentPiece.shape = oldShape;
    drawBackground();
}

drawGrid();
selectLevel(getSelectLevel());
levelInput.forEach(input => {
    input.addEventListener("change", function () {
        selectLevel(this.value);
    });
});

// gan cac nut vao su kien choi game
startButton.addEventListener("click", startGame);
stopButton.addEventListener("click", pauseGame);
restartButton.addEventListener("click", restartGame);
document.addEventListener("keydown", function (event) {
    const arrowKey = [
        "ArrowLeft",
        "ArrowRight",
        "ArrowDown",
        "ArrowUp"
    ];
    if (arrowKey.includes(event.key)) event.preventDefault();
    if (gameTime === null || gameOver) return;
    switch (event.key) {
        case "ArrowLeft":
            movePiece(-1);
            break;
        case "ArrowRight":
            movePiece(1);
            break;
        case "ArrowDown":
            moveDown();
            break;
        case "ArrowUp":
            if (!event.repeat) rotatePiece();
            break;
    }
});
